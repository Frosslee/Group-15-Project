# Group-15-Project
Tello drone Project 
----------------------
A Final year project for Belgium Campus designed by:
# Fill in names
---
---
---
This is software for a Tello drone to make it apropriate for use by agricultural farmers and/or livestock.
# or -\_0_/-
This application modifies a Tello drone so that it can be used by livestock or agricultural farmers.
